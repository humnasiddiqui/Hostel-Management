<style>
table, th, td {
  border: 1px solid black;
}
</style>
<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "responsiveform";

$conn = mysqli_connect($servername,$username,$password,$dbname);
$sql = "SELECT users.email,users.fname,room.room_no,payment.amount FROM `users` LEFT JOIN room on users.room_id = room.id LEFT JOIN payment on users.id = payment.user_id;";
        $result = $conn->query($sql); //-> this operator use for call the member function or member variable
         //print_r($result)
        //exit;
            if ($result->num_rows > 0) {?>
                <table>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Room</th>
                        <th>Payment</th>
                    </tr>
                    <?php
                    while($row = $result->fetch_assoc()) { // fetch_assoc() fetches a result row as an associative array
                    ?>
                        <tr>
                        <td><?php echo $row["fname"]; ?></td>
                        <td><?php echo $row["email"]; ?></td>
                        <td><?php echo $row["room_no"]; ?></td>
                        <td><?php echo $row["amount"]; ?></td>
                    </tr>
               <?php }?>
                </table>
                <?php
            
            }  
           else {
            echo "No record Found";
          }
          $conn->close();
          ?>