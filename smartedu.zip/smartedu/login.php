<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "responsiveform";

$conn = mysqli_connect($servername,$username,$password,$dbname);

// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
if(!empty($_POST['email']) && !empty($_POST['pass']))
    $email = $_POST['email']; //An associative array of variables passed to the current script via the HTTP POST method.
    $pass = $_POST['pass'];
        // Prepare a select statement
        $sql = "SELECT * FROM `users` WHERE email='$email' AND pass='$pass'";
        $result = $conn->query($sql);
        
            // if ($_POST['email'] == 'tutorialspoint' && 
            //       $_POST['password'] == '1234') {
            if ($result->num_rows > 0) {
                $_SESSION['valid'] = true; //An associative array containing session variables available to the current script. See the Session functions documentation for more information on how this is used.
                $_SESSION['timeout'] = time();
                $_SESSION['email'] = 'admin@gmail.com';
                
                echo 'You have entered valid use name and password';
                 // output data of each row
            // while($row = $result->fetch_assoc()) {
                //   echo "id: " . $row["id"]. " - Name: " . $row["fname"]. " " . $row["pass"]. "<br>";
                // echo "Logged In";
                header('Refresh: 1; URL = registration.php');
                }
            // }  
           
        // }
        //   }
           else {
            echo "Invalid Email or Password";
            header('Refresh: 1; URL = index.php');
          }
          $conn->close();