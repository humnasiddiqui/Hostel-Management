<?php
/* Attempt MySQL server connection. Assuming you are running MySQL
server with default setting (user 'root' with no password) */
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "responsiveform";

$conn = mysqli_connect($servername,$username,$password,$dbname);
 
// Check connection
if($conn === false){
    die("ERROR: Could not connect. " . mysqli_connect_error());
}
 
// Escape user inputs for security
$first_name = mysqli_real_escape_string($conn, $_REQUEST['fname']); //This function is used to create a legal SQL string that can be used in an SQL statement.
$email = mysqli_real_escape_string($conn, $_REQUEST['email']);
$father_name = mysqli_real_escape_string($conn, $_REQUEST['father_name']);
$mobile = mysqli_real_escape_string($conn, $_REQUEST['mob_no']);
$payment = mysqli_real_escape_string($conn, $_REQUEST['payment']);
$room = mysqli_real_escape_string($conn, $_REQUEST['room']);

 
// Attempt insert query execution
$sql = "INSERT INTO users (id, fname, email, father_name, mob_no, room_id) VALUES ('' ,'$first_name', '$email', '$father_name','$mobile','$room')";
// $sql .="INSERT INTO payment (id, user_id, amount) VALUES ('' ,'$sql->id', '$email', '$father_name','$mobile','$payment','$room')";
if ($conn->query($sql) === TRUE) {
    $last_id = $conn->insert_id;
    // echo "New record created successfully. Last inserted ID is: " . $last_id;
    $sql = "INSERT INTO payment (id, user_id, amount) VALUES ('' ,'$last_id', '$payment')";
    mysqli_query($conn, $sql);
    echo "Records added successfully.";
    header('Refresh: 1; URL = registration.php');
}
// if(mysqli_query($conn, $sql)){
// } 
else{
    echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
}
 
// Close connection
mysqli_close($conn);
?>